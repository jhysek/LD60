trackr-sequence v1

Load this ZIP with the Godot 4.5+ TrackrPlayer addon, or extract it and load sequence.json.
The addon and documentation are in the trackr repository under godot/.
Add *.zip to your Godot export preset non-resource include filter to bundle this pack.
Time is measured in rows (4 rows per beat). Mute/solo are baked into this export.
WAVs are individual mono/stereo 16-bit PCM samples, not a rendered soundtrack.
